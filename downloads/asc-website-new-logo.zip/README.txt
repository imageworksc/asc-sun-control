Atlantic Sun Control: new logo (3B) in the menu and homepage
==============================================================

What changed
------------
- New logo in the menu bar of menu.html and homepage-option-2.html.
  It plays its animation once when the page loads (about 3 seconds:
  the sun rises, the bands appear, then the name), then stays still.
  Visitors who turn on "reduce motion" see the finished logo straight away.
- New favicon and home screen icon on both pages.
- assets/menu/menu.css: logo size and spacing in the bar for the new logo.
  The bar switches to its compact layout (phone icon without the number)
  below 1280 px instead of 1180 px, so the links never crowd the logo.

Files to upload (keep the same folders)
---------------------------------------
  menu.html
  homepage-option-2.html
  assets/menu/            menu.css, menu.js, page.css
  assets/homepage-option-2/
  assets/brand/           the logo, its animation and the icons (new folder)

assets/brand
------------
  asc-logo-animated-once.svg  logo in the menu bar (plays once)
  asc-logo.svg                static logo, for light backgrounds
  asc-logo-white.svg          static logo, for dark backgrounds
  asc-symbol.svg              the sun on its own
  favicon.svg, favicon-32.png browser tab icon
  apple-touch-icon.png        home screen icon (180 x 180)
  icon-512.png                large icon (512 x 512), for app manifests or social profiles

After uploading
---------------
The pages ask for menu.css?v=25 and the brand files with ?v=1, so browsers
load the new files instead of cached copies. If a CDN caches the site,
purge it once.

logo.png is no longer used by these two pages. Other older pages in the
project still use it, so do not delete it until they are updated too.
