Atlantic Sun Control logo, Option 3B
=====================================

The sun over the Atlantic, with "Atlantic / Sun Control" set in Figtree
SemiBold (600). The text is outlined in every file, so no font is needed.

Folders
-------
  logo/       full logo: svg, pdf and png (transparent, 2400 px wide)
              -light = for light backgrounds, -dark = for dark backgrounds
  symbol/     the sun on its own: svg, pdf and png
  animation/  animated SVG logos, light and dark
              -animated       loops every 5.6 seconds (for a hero or a video end card)
              -animated-once  plays once, then stays still (for a site header)
              Both work as a plain <img> and respect "reduce motion".
  icons/      favicon.svg, favicon-32.png, apple-touch-icon.png (180), icon-512.png
  spacing/    the spacing grid drawn on the logo

Colours
-------
  Orange  #E8540A   the sun
  Ink     #1E2129   the name on light backgrounds
  White   #FFFFFF   the name on dark backgrounds

Spacing
-------
  One unit (u) is one sixth of the height of the two lines of the name.
  - Capitals 2.5u, with 1u from the first baseline to the next capitals
  - The sun is 7u high, centred on the name
  - Sun to name: 1u
  - Clear space: keep 2u free on every side

Minimum sizes
-------------
  Logo:   28 px high on screen
  Symbol: 24 px high (below that, the bands start to merge)

Do not
------
  - stretch, rotate or recolour the logo
  - set the name in another typeface
  - place it on busy photos without enough contrast
